import { useMemo, useState } from "react"

type IconName = "arrow" | "bag" | "check" | "chevron" | "close" | "heart" | "home" | "minus" | "plus" | "search" | "shop" | "user"

type Product = {
  id: number
  name: string
  category: string
  price: number
  image: string
  color: string
  badge?: string
}

const products: Product[] = [
  {
    id: 1,
    name: "Linen Sandal",
    category: "Shoes",
    price: 128,
    color: "Oat",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1661200523537-dcaaa8bb3369?auto=format&fit=crop&w=900&q=85",
  },
  {
    id: 2,
    name: "Everyday Objects",
    category: "Accessories",
    price: 94,
    color: "Espresso",
    image:
      "https://images.unsplash.com/photo-1680690653166-1618c3bcdf51?auto=format&fit=crop&w=900&q=85",
  },
  {
    id: 3,
    name: "Dune Timepiece",
    category: "Accessories",
    price: 176,
    color: "Rose",
    badge: "Bestseller",
    image:
      "https://images.unsplash.com/photo-1675001849511-509a2351ff69?auto=format&fit=crop&w=900&q=85",
  },
  {
    id: 4,
    name: "Sunday Knit",
    category: "Clothing",
    price: 88,
    color: "Ivory",
    image:
      "https://images.unsplash.com/photo-1654773125909-6d73f0c12407?auto=format&fit=crop&w=900&q=85",
  },
  {
    id: 5,
    name: "Studio Frames",
    category: "Accessories",
    price: 72,
    color: "Tortoise",
    image:
      "https://images.unsplash.com/photo-1668819584056-6b4f13145988?auto=format&fit=crop&w=900&q=85",
  },
  {
    id: 6,
    name: "Muse Ring",
    category: "Jewelry",
    price: 64,
    color: "Gold",
    image:
      "https://images.unsplash.com/photo-1668819584032-40dc67cb8171?auto=format&fit=crop&w=900&q=85",
  },
]

const categories = ["All", "Clothing", "Shoes", "Accessories", "Jewelry"]

function Icon({
  name,
  size = 20,
  filled = false,
}: {
  name: IconName
  size?: number
  filled?: boolean
}) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    bag: (
      <>
        <path d="M5 8h14l-1 12H6L5 8Z" />
        <path d="M9 9V6a3 3 0 0 1 6 0v3" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
    ),
    home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v10h14V10M9 20v-6h6v6" />
      </>
    ),
    minus: <path d="M5 12h14" />,
    plus: <path d="M12 5v14M5 12h14" />,
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    shop: (
      <>
        <path d="M4 9h16l-1 11H5L4 9Z" />
        <path d="m7 9 1-5h8l1 5" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
  }

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function ProductCard({
  product,
  favorite,
  onFavorite,
  onOpen,
  onAdd,
}: {
  product: Product
  favorite: boolean
  onFavorite: () => void
  onOpen: () => void
  onAdd: () => void
}) {
  return (
    <article className="group min-w-0">
      <div className="relative aspect-[4/5] overflow-hidden rounded-[1.4rem] bg-stone-100">
        <button
          type="button"
          onClick={onOpen}
          className="h-full w-full cursor-pointer"
          aria-label={`View ${product.name}`}
        >
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        </button>
        {product.badge && (
          <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-stone-700 backdrop-blur">
            {product.badge}
          </span>
        )}
        <button
          type="button"
          onClick={onFavorite}
          className={`absolute right-3 top-3 grid size-9 place-items-center rounded-full backdrop-blur transition ${
            favorite
              ? "bg-[#d95d39] text-white"
              : "bg-white/90 text-stone-700 hover:bg-white"
          }`}
          aria-label={favorite ? "Remove from saved" : "Save item"}
        >
          <Icon name="heart" size={16} filled={favorite} />
        </button>
        <button
          type="button"
          onClick={onAdd}
          className="absolute bottom-3 right-3 grid size-10 place-items-center rounded-full bg-[#24211e] text-white shadow-lg transition hover:scale-105"
          aria-label={`Add ${product.name} to bag`}
        >
          <Icon name="plus" size={18} />
        </button>
      </div>
      <button type="button" onClick={onOpen} className="mt-3 w-full text-left">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-[#24211e]">
              {product.name}
            </p>
            <p className="mt-0.5 text-xs text-stone-500">{product.color}</p>
          </div>
          <p className="text-sm font-semibold text-[#24211e]">
            ${product.price}
          </p>
        </div>
      </button>
    </article>
  )
}

function EmptyState({
  icon,
  title,
  copy,
  action,
}: {
  icon: IconName
  title: string
  copy: string
  action: () => void
}) {
  return (
    <div className="flex min-h-[55vh] flex-col items-center justify-center px-8 text-center">
      <div className="grid size-16 place-items-center rounded-full bg-[#efe8de] text-[#9a5f45]">
        <Icon name={icon} size={27} />
      </div>
      <p className="mt-5 font-serif text-3xl text-[#24211e]">{title}</p>
      <p className="mt-2 max-w-64 text-sm leading-6 text-stone-500">{copy}</p>
      <button
        type="button"
        onClick={action}
        className="mt-6 rounded-full bg-[#24211e] px-6 py-3 text-sm font-semibold text-white"
      >
        Explore the collection
      </button>
    </div>
  )
}

export default function App() {
  const [tab, setTab] = useState("home")
  const [category, setCategory] = useState("All")
  const [query, setQuery] = useState("")
  const [favorites, setFavorites] = useState<number[]>([3])
  const [cart, setCart] = useState<Record<number, number>>({})
  const [selected, setSelected] = useState<Product | null>(null)
  const [toast, setToast] = useState("")

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        category === "All" || product.category === category
      const matchesSearch = product.name
        .toLowerCase()
        .includes(query.toLowerCase())
      return matchesCategory && matchesSearch
    })
  }, [category, query])

  const savedProducts = products.filter((product) =>
    favorites.includes(product.id),
  )
  const cartProducts = products.filter((product) => cart[product.id])
  const cartCount = Object.values(cart).reduce((sum, count) => sum + count, 0)
  const subtotal = cartProducts.reduce(
    (sum, product) => sum + product.price * cart[product.id],
    0,
  )

  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(""), 1800)
  }

  const addToCart = (product: Product) => {
    setCart((current) => ({
      ...current,
      [product.id]: (current[product.id] || 0) + 1,
    }))
    notify(`${product.name} added to bag`)
  }

  const toggleFavorite = (id: number) => {
    setFavorites((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    )
  }

  const goShop = () => {
    setTab("shop")
    setCategory("All")
  }

  const renderGrid = (items: Product[]) => (
    <div className="grid grid-cols-2 gap-x-3.5 gap-y-7">
      {items.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          favorite={favorites.includes(product.id)}
          onFavorite={() => toggleFavorite(product.id)}
          onOpen={() => setSelected(product)}
          onAdd={() => addToCart(product)}
        />
      ))}
    </div>
  )

  return (
    <main className="min-h-screen bg-[#d9d1c5] text-[#24211e] sm:grid sm:place-items-center sm:p-8">
      <div className="relative min-h-screen w-full overflow-hidden bg-[#fbfaf7] sm:min-h-[844px] sm:max-w-[430px] sm:rounded-[2.4rem] sm:border-[7px] sm:border-[#24211e] sm:shadow-2xl">
        <div className="h-screen min-h-[700px] overflow-y-auto pb-24 sm:h-[830px]">
          <header className="sticky top-0 z-20 flex items-center justify-between bg-[#fbfaf7]/90 px-5 pb-3 pt-5 backdrop-blur-xl">
            <button
              type="button"
              onClick={() => setTab("home")}
              className="font-serif text-[1.65rem] tracking-[-0.03em]"
            >
              Selene
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setTab("shop")}
                className="grid size-10 place-items-center rounded-full bg-white text-stone-700 shadow-sm ring-1 ring-stone-200"
                aria-label="Search products"
              >
                <Icon name="search" size={18} />
              </button>
              <button
                type="button"
                onClick={() => setTab("cart")}
                className="relative grid size-10 place-items-center rounded-full bg-[#24211e] text-white"
                aria-label="View bag"
              >
                <Icon name="bag" size={18} />
                {cartCount > 0 && (
                  <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-[#d95d39] text-[10px] font-bold ring-2 ring-[#fbfaf7]">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </header>

          {tab === "home" && (
            <div className="px-5">
              <section className="relative mt-2 h-[430px] overflow-hidden rounded-[1.8rem]">
                <img
                  src="https://images.unsplash.com/photo-1613915617430-8ab0fd7c6baf?auto=format&fit=crop&w=1000&q=90"
                  alt="Model wearing the new season collection"
                  className="h-full w-full object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/5 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 text-white">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/75">
                    The quiet collection
                  </span>
                  <p className="mt-2 max-w-72 font-serif text-[2.7rem] leading-[0.95] tracking-[-0.035em]">
                    Made for slow mornings
                  </p>
                  <button
                    type="button"
                    onClick={goShop}
                    className="mt-5 flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-semibold text-[#24211e]"
                  >
                    Shop new arrivals <Icon name="arrow" size={17} />
                  </button>
                </div>
              </section>

              <section className="py-8">
                <div className="mb-4 flex items-end justify-between">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#a56a4b]">
                      Curated for you
                    </p>
                    <p className="mt-1 font-serif text-[1.85rem] leading-none">
                      Freshly found
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={goShop}
                    className="text-xs font-semibold underline underline-offset-4"
                  >
                    View all
                  </button>
                </div>
                {renderGrid(products.slice(0, 4))}
              </section>

              <section className="mb-4 overflow-hidden rounded-[1.5rem] bg-[#dfe5d5] p-6">
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#536044]">
                  Selene circle
                </p>
                <p className="mt-3 max-w-xs font-serif text-3xl leading-[1.02]">
                  Thoughtful pieces, special perks.
                </p>
                <p className="mt-3 text-sm leading-6 text-stone-600">
                  Join our community for early access, private edits, and
                  complimentary delivery.
                </p>
                <button
                  type="button"
                  onClick={() => notify("Membership preview opened")}
                  className="mt-5 flex items-center gap-2 text-sm font-bold"
                >
                  Discover membership <Icon name="arrow" size={16} />
                </button>
              </section>
            </div>
          )}

          {tab === "shop" && (
            <div className="px-5">
              <div className="pb-5 pt-3">
                <p className="font-serif text-[2.5rem] leading-none">
                  The collection
                </p>
                <p className="mt-2 text-sm text-stone-500">
                  Considered pieces for every day.
                </p>
              </div>
              <label className="flex h-12 items-center gap-3 rounded-full bg-white px-4 ring-1 ring-stone-200">
                <Icon name="search" size={18} />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search the collection"
                  className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-stone-400"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    aria-label="Clear search"
                  >
                    <Icon name="close" size={16} />
                  </button>
                )}
              </label>
              <div className="-mx-5 flex gap-2 overflow-x-auto px-5 py-5 [scrollbar-width:none]">
                {categories.map((item) => (
                  <button
                    type="button"
                    key={item}
                    onClick={() => setCategory(item)}
                    className={`shrink-0 rounded-full px-4 py-2 text-xs font-semibold transition ${
                      category === item
                        ? "bg-[#24211e] text-white"
                        : "bg-[#efece6] text-stone-600"
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>
              <div className="mb-4 flex items-center justify-between">
                <p className="text-xs text-stone-500">
                  {filteredProducts.length} pieces
                </p>
                <button
                  type="button"
                  className="flex items-center gap-1 text-xs font-semibold"
                >
                  Curated <Icon name="chevron" size={14} />
                </button>
              </div>
              {filteredProducts.length ? (
                renderGrid(filteredProducts)
              ) : (
                <div className="py-24 text-center">
                  <p className="font-serif text-2xl">No pieces found</p>
                  <button
                    type="button"
                    onClick={() => {
                      setQuery("")
                      setCategory("All")
                    }}
                    className="mt-3 text-sm font-semibold underline"
                  >
                    Reset filters
                  </button>
                </div>
              )}
            </div>
          )}

          {tab === "saved" && (
            <div className="px-5">
              <div className="pb-6 pt-3">
                <p className="font-serif text-[2.5rem] leading-none">
                  Saved pieces
                </p>
                <p className="mt-2 text-sm text-stone-500">
                  A place for the things you love.
                </p>
              </div>
              {savedProducts.length ? (
                renderGrid(savedProducts)
              ) : (
                <EmptyState
                  icon="heart"
                  title="Nothing saved yet"
                  copy="Tap the heart on any piece to keep it close."
                  action={goShop}
                />
              )}
            </div>
          )}

          {tab === "cart" && (
            <div className="px-5">
              <div className="pb-6 pt-3">
                <p className="font-serif text-[2.5rem] leading-none">
                  Your bag
                </p>
                <p className="mt-2 text-sm text-stone-500">
                  {cartCount
                    ? `${cartCount} ${
                        cartCount === 1 ? "piece" : "pieces"
                      } selected`
                    : "Ready when you are."}
                </p>
              </div>
              {cartProducts.length ? (
                <>
                  <div className="space-y-4">
                    {cartProducts.map((product) => (
                      <article
                        key={product.id}
                        className="flex gap-4 border-b border-stone-200 pb-4"
                      >
                        <img
                          src={product.image}
                          alt={product.name}
                          className="h-28 w-24 rounded-2xl object-cover"
                        />
                        <div className="flex min-w-0 flex-1 flex-col py-1">
                          <div className="flex justify-between gap-2">
                            <div>
                              <p className="text-sm font-semibold">
                                {product.name}
                              </p>
                              <p className="mt-1 text-xs text-stone-500">
                                {product.color}
                              </p>
                            </div>
                            <p className="text-sm font-semibold">
                              ${product.price * cart[product.id]}
                            </p>
                          </div>
                          <div className="mt-auto flex items-center justify-between">
                            <div className="flex items-center rounded-full bg-stone-100 p-1">
                              <button
                                type="button"
                                onClick={() =>
                                  setCart((current) => {
                                    const next = { ...current }
                                    next[product.id] -= 1
                                    if (next[product.id] <= 0)
                                      delete next[product.id]
                                    return next
                                  })
                                }
                                className="grid size-7 place-items-center"
                                aria-label="Decrease quantity"
                              >
                                <Icon name="minus" size={14} />
                              </button>
                              <span className="w-7 text-center text-xs font-semibold">
                                {cart[product.id]}
                              </span>
                              <button
                                type="button"
                                onClick={() => addToCart(product)}
                                className="grid size-7 place-items-center"
                                aria-label="Increase quantity"
                              >
                                <Icon name="plus" size={14} />
                              </button>
                            </div>
                            <button
                              type="button"
                              onClick={() =>
                                setCart((current) => {
                                  const next = { ...current }
                                  delete next[product.id]
                                  return next
                                })
                              }
                              className="text-xs text-stone-500 underline"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                  <div className="mt-7 rounded-[1.5rem] bg-[#efe8de] p-5">
                    <div className="flex justify-between text-sm">
                      <span className="text-stone-600">Subtotal</span>
                      <span className="font-semibold">${subtotal}</span>
                    </div>
                    <div className="mt-3 flex justify-between text-sm">
                      <span className="text-stone-600">Delivery</span>
                      <span className="font-semibold text-[#536044]">
                        Complimentary
                      </span>
                    </div>
                    <div className="my-4 border-t border-stone-300" />
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>${subtotal}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => notify("Checkout flow ready for review")}
                    className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-[#24211e] py-4 text-sm font-semibold text-white"
                  >
                    Continue to checkout <Icon name="arrow" size={18} />
                  </button>
                  <p className="mt-3 text-center text-[11px] text-stone-400">
                    Secure checkout · Easy 30-day returns
                  </p>
                </>
              ) : (
                <EmptyState
                  icon="bag"
                  title="Your bag is empty"
                  copy="Explore our latest edit and find something made to last."
                  action={goShop}
                />
              )}
            </div>
          )}
        </div>

        <nav className="absolute inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-stone-200 bg-[#fbfaf7]/95 px-3 pb-5 pt-2 backdrop-blur-xl">
          {[
            { id: "home", label: "Home", icon: "home" as IconName },
            { id: "shop", label: "Shop", icon: "shop" as IconName },
            { id: "saved", label: "Saved", icon: "heart" as IconName },
            { id: "cart", label: "Bag", icon: "bag" as IconName },
          ].map((item) => (
            <button
              type="button"
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`relative flex flex-col items-center gap-1 py-1 text-[10px] font-semibold transition ${
                tab === item.id ? "text-[#24211e]" : "text-stone-400"
              }`}
            >
              <Icon
                name={item.icon}
                size={20}
                filled={tab === item.id && item.id === "saved"}
              />
              {item.label}
              {item.id === "cart" && cartCount > 0 && (
                <span className="absolute right-[23%] top-0 size-2 rounded-full bg-[#d95d39]" />
              )}
            </button>
          ))}
        </nav>

        {selected && (
          <div className="absolute inset-0 z-40 flex items-end bg-black/35 backdrop-blur-[2px]">
            <button
              type="button"
              className="absolute inset-0"
              onClick={() => setSelected(null)}
              aria-label="Close product detail"
            />
            <section className="relative max-h-[92%] w-full overflow-y-auto rounded-t-[2rem] bg-[#fbfaf7] p-5 pb-8">
              <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-stone-300" />
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="absolute right-5 top-5 grid size-9 place-items-center rounded-full bg-white shadow-sm"
                aria-label="Close"
              >
                <Icon name="close" size={18} />
              </button>
              <img
                src={selected.image}
                alt={selected.name}
                className="h-80 w-full rounded-[1.5rem] object-cover"
              />
              <div className="pt-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#a56a4b]">
                      {selected.category}
                    </p>
                    <p className="mt-1 font-serif text-[2rem] leading-none">
                      {selected.name}
                    </p>
                  </div>
                  <p className="text-lg font-semibold">${selected.price}</p>
                </div>
                <p className="mt-4 text-sm leading-6 text-stone-500">
                  Designed with a quiet point of view and crafted for everyday
                  wear. A timeless piece you will reach for season after season.
                </p>
                <div className="mt-5 flex items-center justify-between rounded-2xl bg-stone-100 px-4 py-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-stone-400">
                      Selected color
                    </p>
                    <p className="mt-1 text-sm font-semibold">
                      {selected.color}
                    </p>
                  </div>
                  <div className="grid size-7 place-items-center rounded-full bg-[#9a755f] text-white ring-4 ring-white">
                    <Icon name="check" size={14} />
                  </div>
                </div>
                <div className="mt-5 flex gap-3">
                  <button
                    type="button"
                    onClick={() => toggleFavorite(selected.id)}
                    className={`grid size-14 shrink-0 place-items-center rounded-full ring-1 ring-stone-300 ${
                      favorites.includes(selected.id)
                        ? "bg-[#d95d39] text-white ring-[#d95d39]"
                        : ""
                    }`}
                    aria-label="Save item"
                  >
                    <Icon
                      name="heart"
                      size={20}
                      filled={favorites.includes(selected.id)}
                    />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      addToCart(selected)
                      setSelected(null)
                    }}
                    className="flex h-14 flex-1 items-center justify-center gap-2 rounded-full bg-[#24211e] text-sm font-semibold text-white"
                  >
                    Add to bag <Icon name="bag" size={17} />
                  </button>
                </div>
              </div>
            </section>
          </div>
        )}

        {toast && (
          <div className="absolute bottom-24 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full bg-[#24211e] px-4 py-3 text-xs font-semibold text-white shadow-xl">
            <Icon name="check" size={15} /> {toast}
          </div>
        )}
      </div>
    </main>
  )
}
